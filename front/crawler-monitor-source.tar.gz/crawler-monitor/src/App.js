import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Sidebar from './components/Sidebar';
import Dashboard from './pages/Dashboard';
import Processing from './pages/Processing';
import Reports from './pages/Reports';
import SavedResults from './pages/SavedResults';
import StatusManagement from './pages/StatusManagement';
import './App.css';

function App() {
  return (
    <Router>
      <div className="app-container">
        <Sidebar />
        <div className="main-content">
          <Routes>
            <Route path="/" element={<Dashboard />} />
            <Route path="/processing" element={<Processing />} />
            <Route path="/reports" element={<Reports />} />
            <Route path="/saved-results" element={<SavedResults />} />
            <Route path="/status-management" element={<StatusManagement />} />
          </Routes>
        </div>
      </div>
    </Router>
  );
}

export default App;
