import React, { useState } from 'react';
import { Activity, CheckCircle, Clock, XCircle } from 'lucide-react';
import './Processing.css';

const Processing = () => {
  const [phase] = useState(1);
  const [progress] = useState(28);
  const [logs] = useState([
    { time: '00:00:01', message: '크롤링 시작...' },
    { time: '00:00:02', message: '7개 브라우저 풀 초기화 완료' },
    { time: '00:00:03', message: 'Phase 1 시작 (20초 타임아웃)' },
    { time: '00:00:23', message: 'GTM 컨테이너 확인 완료' },
    { time: '00:00:47', message: 'GTM 컨테이너 확인 완료' },
    { time: '00:00:51', message: 'GA4 이벤트 감지 성공' },
    { time: '00:00:32', message: 'GTM 컨테이너 확인 완료' }
  ]);
  
  const browserPool = [
    { id: 1, name: 'Browser #1', url: 'property-001.com', status: 'checking' },
    { id: 2, name: 'Browser #2', url: 'property-045.com', status: 'completed' },
    { id: 3, name: 'Browser #3', url: 'property-089.com', status: 'checking' },
    { id: 4, name: 'Browser #4', url: 'property-123.com', status: 'waiting' },
    { id: 5, name: 'Browser #5', url: 'property-167.com', status: 'checking' },
    { id: 6, name: 'Browser #6', url: 'property-201.com', status: 'error' }
  ];

  const getStatusBadge = (status) => {
    switch(status) {
      case 'completed':
        return { label: '완료', className: 'badge-success', icon: CheckCircle };
      case 'checking':
        return { label: '진행중', className: 'badge-primary', icon: Activity };
      case 'waiting':
        return { label: '대기중', className: 'badge-gray', icon: Clock };
      case 'error':
        return { label: '실패', className: 'badge-error', icon: XCircle };
      default:
        return { label: '대기중', className: 'badge-gray', icon: Clock };
    }
  };

  return (
    <div className="page-container">
      <div className="page-header">
        <h1>크롤링 진행 중</h1>
        <p className="page-subtitle">실시간 크롤링 상태 및 로그</p>
      </div>

      <div className="processing-content">
        <div className="phase-section">
          <div className="phase-header">
            <h3>Phase {phase}</h3>
            <div className="progress-badge">{progress}%</div>
          </div>
          <p className="phase-description">
            {phase === 1 
              ? '1차 스크립트 검증 (20초 타임아웃)' 
              : '2차 스크립트 검증 (60초 타임아웃)'}
          </p>
          
          <div className="progress-bar">
            <div className="progress-fill" style={{ width: `${progress}%` }}></div>
          </div>
        </div>

        <div className="processing-grid">
          <div className="browser-pool-section">
            <h3>브라우저 풀 상태</h3>
            <p className="section-subtitle">7개 동시 실행 중</p>
            
            <div className="browser-list">
              {browserPool.map((browser) => {
                const status = getStatusBadge(browser.status);
                const StatusIcon = status.icon;
                
                return (
                  <div key={browser.id} className="browser-item">
                    <div className="browser-icon">
                      <StatusIcon size={24} />
                    </div>
                    <div className="browser-info">
                      <p className="browser-name">{browser.name}</p>
                      <p className="browser-url">{browser.url}</p>
                    </div>
                    <span className={`status-badge ${status.className}`}>
                      {status.label}
                    </span>
                  </div>
                );
              })}
            </div>
          </div>

          <div className="log-section">
            <h3>실시간 로그</h3>
            <p className="section-subtitle">크롤링 프로세스 메시지</p>
            
            <div className="log-container">
              {logs.map((log, index) => (
                <div key={index} className="log-entry">
                  <span className="log-time">[{log.time}]</span>
                  <span className="log-message">{log.message}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Processing;
