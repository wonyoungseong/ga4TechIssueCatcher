import React, { useState } from 'react';
import { CheckCircle, AlertCircle, Search, ExternalLink } from 'lucide-react';
import './Reports.css';

const Reports = () => {
  const [searchQuery, setSearchQuery] = useState('');
  
  const summaryStats = {
    totalCrawled: 3,
    issuesFound: 2
  };
  
  const siteResults = [
    {
      id: 1,
      url: 'https://property-001.example.com',
      status: 'normal',
      screenshot: '/screenshots/property-001.png',
      collectedGA4: 'G-ABC123456',
      expectedGA4: 'G-ABC123456',
      collectedGTM: 'GTM-XYZ789',
      expectedGTM: 'GTM-XYZ789',
      pageViewEvent: true
    },
    {
      id: 2,
      url: 'https://property-045.example.com',
      status: 'issue',
      screenshot: '/screenshots/property-045.png',
      collectedGA4: 'G-DEF789012',
      expectedGA4: 'G-ABC123456',
      collectedGTM: null,
      expectedGTM: 'GTM-XYZ789',
      pageViewEvent: false
    },
    {
      id: 3,
      url: 'https://property-089.example.com',
      status: 'issue',
      screenshot: '/screenshots/property-089.png',
      collectedGA4: null,
      expectedGA4: 'G-ABC123456',
      collectedGTM: 'GTM-XYZ789',
      expectedGTM: 'GTM-XYZ789',
      pageViewEvent: false
    }
  ];

  const filteredSites = siteResults.filter(site => 
    site.url.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="page-container">
      <div className="page-header">
        <h1>크롤링 리포트</h1>
        <p className="page-subtitle">이슈 사이트 상세 정보</p>
      </div>

      <div className="report-summary">
        <div className="summary-card summary-blue">
          <h3>{summaryStats.totalCrawled}개</h3>
          <p>총 크롤링 페이지</p>
        </div>
        <div className="summary-card summary-orange">
          <h3>{summaryStats.issuesFound}개</h3>
          <p>이슈가 있는 사이트</p>
        </div>
      </div>

      <div className="report-content">
        <div className="content-header">
          <h3>이슈 사이트 목록</h3>
          <p className="section-subtitle">프로퍼티별 상세 정보</p>
        </div>

        <div className="search-box">
          <Search size={20} className="search-icon" />
          <input
            type="text"
            placeholder="URL 검색..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="search-input"
          />
        </div>

        <div className="results-table">
          <table>
            <thead>
              <tr>
                <th>URL</th>
                <th>상태</th>
                <th>수집 GA4</th>
                <th>예상 GA4</th>
                <th>수집 GTM</th>
                <th>예상 GTM</th>
                <th>Page View</th>
                <th>액션</th>
              </tr>
            </thead>
            <tbody>
              {filteredSites.map((site) => (
                <tr key={site.id} className={site.status === 'issue' ? 'row-issue' : ''}>
                  <td className="url-cell">
                    <a href={site.url} target="_blank" rel="noopener noreferrer">
                      {site.url}
                    </a>
                  </td>
                  <td>
                    <span className={`status-indicator ${site.status === 'normal' ? 'status-normal' : 'status-issue'}`}>
                      {site.status === 'normal' ? (
                        <>
                          <CheckCircle size={16} />
                          정상
                        </>
                      ) : (
                        <>
                          <AlertCircle size={16} />
                          오류
                        </>
                      )}
                    </span>
                  </td>
                  <td className={!site.collectedGA4 ? 'cell-missing' : site.collectedGA4 !== site.expectedGA4 ? 'cell-mismatch' : ''}>
                    {site.collectedGA4 || '없음'}
                  </td>
                  <td>{site.expectedGA4}</td>
                  <td className={!site.collectedGTM ? 'cell-missing' : site.collectedGTM !== site.expectedGTM ? 'cell-mismatch' : ''}>
                    {site.collectedGTM || '없음'}
                  </td>
                  <td>{site.expectedGTM}</td>
                  <td>
                    <span className={`event-badge ${site.pageViewEvent ? 'event-yes' : 'event-no'}`}>
                      {site.pageViewEvent ? '○' : '✕'}
                    </span>
                  </td>
                  <td>
                    <button className="btn-detail">
                      <ExternalLink size={16} />
                      상세
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default Reports;
