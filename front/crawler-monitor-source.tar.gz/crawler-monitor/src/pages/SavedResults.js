import React from 'react';
import { FileText, Download, Eye } from 'lucide-react';
import './SavedResults.css';

const SavedResults = () => {
  const savedReports = [
    {
      date: '2025-01-15',
      totalSites: 247,
      issues: 23
    },
    {
      date: '2025-01-14',
      totalSites: 247,
      issues: 19
    },
    {
      date: '2025-01-13',
      totalSites: 247,
      issues: 28,
      hasIssues: true
    },
    {
      date: '2025-01-12',
      totalSites: 247,
      issues: 31,
      hasIssues: true
    },
    {
      date: '2025-01-11',
      totalSites: 247,
      issues: 25
    }
  ];

  const processingStatus = [
    { property: 'property-001.com', status: 'normal', lastChecked: '2025-01-15' },
    { property: 'property-045.com', status: 'debugging', lastChecked: '2025-01-14' },
    { property: 'property-089.com', status: 'issue', lastChecked: '2025-01-15' },
    { property: 'property-123.com', status: 'normal', lastChecked: '2025-01-15' },
    { property: 'property-167.com', status: 'debugging', lastChecked: '2025-01-13' }
  ];

  const getStatusBadge = (status) => {
    switch(status) {
      case 'normal':
        return { label: '정상', className: 'status-normal' };
      case 'debugging':
        return { label: '디버깅', className: 'status-debugging' };
      case 'issue':
        return { label: '오류', className: 'status-issue' };
      default:
        return { label: '알 수 없음', className: 'status-unknown' };
    }
  };

  return (
    <div className="page-container">
      <div className="page-header">
        <h1>저장된 결과</h1>
        <p className="page-subtitle">일자별 크롤링 리포트 관리</p>
      </div>

      <div className="saved-results-content">
        <div className="reports-section">
          <h3>리포트 히스토리</h3>
          <p className="section-subtitle">과거 크롤링 결과 조회</p>
          
          <div className="reports-list">
            {savedReports.map((report, index) => (
              <div key={index} className="report-item">
                <div className="report-icon">
                  <FileText size={24} />
                </div>
                <div className="report-info">
                  <h4>{report.date}</h4>
                  <div className="report-stats">
                    <span>총 {report.totalSites}개 사이트</span>
                    <span className={report.hasIssues ? 'issues-highlight' : ''}>
                      이슈 {report.issues}개
                    </span>
                  </div>
                </div>
                <div className="report-actions">
                  <button className="btn-icon" title="보기">
                    <Eye size={18} />
                    보기
                  </button>
                  <button className="btn-icon" title="다운로드">
                    <Download size={18} />
                    다운로드
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="status-tracking-section">
          <h3>수리 진행 상태</h3>
          <p className="section-subtitle">이전 오류 기록 추적</p>
          
          <div className="tracking-list">
            {processingStatus.map((item, index) => (
              <div key={index} className="tracking-item">
                <div className="tracking-property">
                  <p className="property-name">{item.property}</p>
                  <p className="property-date">최근 확인: {item.lastChecked}</p>
                </div>
                <span className={`tracking-badge ${getStatusBadge(item.status).className}`}>
                  {getStatusBadge(item.status).label}
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default SavedResults;
