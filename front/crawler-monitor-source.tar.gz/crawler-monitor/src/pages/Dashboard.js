import React from 'react';
import { useNavigate } from 'react-router-dom';
import { TrendingUp, CheckCircle, AlertCircle, Activity } from 'lucide-react';
import './Dashboard.css';

const Dashboard = () => {
  const navigate = useNavigate();
  
  const stats = {
    total: 1247,
    totalChange: '+12%',
    normal: 1089,
    normalChange: '87.3%',
    issues: 158,
    issuesChange: '12.7%'
  };
  
  const recentCrawls = [
    { time: '10분 전', status: '완료', total: 247, issues: 23 },
    { time: '2시간 전', status: '완료', total: 247, issues: 19 },
    { time: '6시간 전', status: '완료', total: 247, issues: 28 }
  ];

  return (
    <div className="page-container">
      <div className="page-header">
        <h1>크롤링 대시보드</h1>
        <p className="page-subtitle">GA4 & GTM 추적 스크립트 모니터링 시스템</p>
      </div>
      
      <div className="dashboard-actions">
        <button 
          className="btn-primary"
          onClick={() => navigate('/processing')}
        >
          <Activity size={20} />
          크롤링 시작
        </button>
      </div>

      <div className="stats-grid">
        <div className="stat-card stat-blue">
          <div className="stat-content">
            <p className="stat-label">총 크롤링 사이트</p>
            <h2 className="stat-value">{stats.total.toLocaleString()}</h2>
          </div>
          <TrendingUp size={48} className="stat-icon" />
          <div className="stat-change">변화율: {stats.totalChange}</div>
        </div>

        <div className="stat-card stat-green">
          <div className="stat-content">
            <p className="stat-label">정상 사이트</p>
            <h2 className="stat-value">{stats.normal.toLocaleString()}</h2>
          </div>
          <CheckCircle size={48} className="stat-icon" />
          <div className="stat-change">변화율: {stats.normalChange}</div>
        </div>

        <div className="stat-card stat-orange">
          <div className="stat-content">
            <p className="stat-label">이슈 사이트</p>
            <h2 className="stat-value">{stats.issues.toLocaleString()}</h2>
          </div>
          <AlertCircle size={48} className="stat-icon" />
          <div className="stat-change">변화율: {stats.issuesChange}</div>
        </div>
      </div>

      <div className="recent-activity">
        <h3>최근 크롤링 활동</h3>
        <p className="section-subtitle">최근 24시간 내 크롤링 기록</p>
        
        <div className="activity-list">
          {recentCrawls.map((crawl, index) => (
            <div key={index} className="activity-item">
              <div className="activity-icon">
                <CheckCircle size={24} className="icon-success" />
              </div>
              <div className="activity-info">
                <p className="activity-status">{crawl.status}</p>
                <p className="activity-time">{crawl.time}</p>
              </div>
              <div className="activity-stats">
                <span className="stat-text">크롤링: <strong>{crawl.total}개</strong></span>
                <span className="stat-text issue">이슈: <strong>{crawl.issues}개</strong></span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
