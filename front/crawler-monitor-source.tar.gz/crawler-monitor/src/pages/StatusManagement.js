import React, { useState } from 'react';
import { CheckCircle, AlertCircle, Wrench, ChevronDown } from 'lucide-react';
import './StatusManagement.css';

const StatusManagement = () => {
  const [properties, setProperties] = useState([
    {
      id: 1,
      name: 'Property 001',
      url: 'property-001.example.com',
      status: 'normal',
      currentStatus: '정상'
    },
    {
      id: 2,
      name: 'Property 045',
      url: 'property-045.example.com',
      status: 'issue',
      currentStatus: '오류'
    },
    {
      id: 3,
      name: 'Property 089',
      url: 'property-089.example.com',
      status: 'debugging',
      currentStatus: '디버깅'
    },
    {
      id: 4,
      name: 'Property 123',
      url: 'property-123.example.com',
      status: 'normal',
      currentStatus: '정상'
    },
    {
      id: 5,
      name: 'Property 167',
      url: 'property-167.example.com',
      status: 'issue',
      currentStatus: '오류'
    }
  ]);

  const statusOptions = [
    { value: 'normal', label: '정상', icon: CheckCircle, color: '#4ECDC4' },
    { value: 'issue', label: '오류', icon: AlertCircle, color: '#FF6B6B' },
    { value: 'debugging', label: '디버깅', icon: Wrench, color: '#FF9F66' }
  ];

  const getStatusIcon = (status) => {
    const option = statusOptions.find(opt => opt.value === status);
    if (option) {
      const Icon = option.icon;
      return <Icon size={20} />;
    }
    return null;
  };

  const getStatusColor = (status) => {
    const option = statusOptions.find(opt => opt.value === status);
    return option ? option.color : '#9CA3AF';
  };

  const handleStatusChange = (propertyId, newStatus) => {
    setProperties(properties.map(prop => 
      prop.id === propertyId 
        ? { 
            ...prop, 
            status: newStatus,
            currentStatus: statusOptions.find(opt => opt.value === newStatus).label
          }
        : prop
    ));
  };

  const summaryStats = {
    normal: properties.filter(p => p.status === 'normal').length,
    debugging: properties.filter(p => p.status === 'debugging').length,
    issue: properties.filter(p => p.status === 'issue').length
  };

  return (
    <div className="page-container">
      <div className="page-header">
        <h1>상태 관리</h1>
        <p className="page-subtitle">프로퍼티별 상태 설정 및 관리</p>
      </div>

      <div className="status-summary">
        <div className="summary-item summary-green">
          <CheckCircle size={24} />
          <div>
            <h3>{summaryStats.normal}개</h3>
            <p>정상 사이트</p>
          </div>
        </div>
        <div className="summary-item summary-orange">
          <Wrench size={24} />
          <div>
            <h3>{summaryStats.debugging}개</h3>
            <p>디버깅 중</p>
          </div>
        </div>
        <div className="summary-item summary-red">
          <AlertCircle size={24} />
          <div>
            <h3>{summaryStats.issue}개</h3>
            <p>오류 사이트</p>
          </div>
        </div>
      </div>

      <div className="status-management-content">
        <div className="content-header">
          <h3>프로퍼티 상태 관리</h3>
          <p className="section-subtitle">각 프로퍼티의 상태를 설정하고 추적합니다</p>
        </div>

        <div className="properties-list">
          {properties.map((property) => (
            <div key={property.id} className="property-card">
              <div 
                className="status-indicator-dot" 
                style={{ backgroundColor: getStatusColor(property.status) }}
              />
              
              <div className="property-info">
                <h4>{property.name}</h4>
                <p>{property.url}</p>
              </div>

              <div className="status-selector">
                <div className="current-status" style={{ color: getStatusColor(property.status) }}>
                  {getStatusIcon(property.status)}
                  <span>{property.currentStatus}</span>
                </div>
                
                <div className="status-dropdown">
                  <select 
                    value={property.status}
                    onChange={(e) => handleStatusChange(property.id, e.target.value)}
                    className="status-select"
                  >
                    {statusOptions.map(option => (
                      <option key={option.value} value={option.value}>
                        {option.label}
                      </option>
                    ))}
                  </select>
                  <ChevronDown size={16} className="dropdown-icon" />
                </div>
              </div>

              <button className="btn-save">저장</button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default StatusManagement;
